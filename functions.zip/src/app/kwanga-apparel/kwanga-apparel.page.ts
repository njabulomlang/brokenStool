import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kwanga-apparel',
  templateUrl: './kwanga-apparel.page.html',
  styleUrls: ['./kwanga-apparel.page.scss'],
})
export class KwangaApparelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

 


}
